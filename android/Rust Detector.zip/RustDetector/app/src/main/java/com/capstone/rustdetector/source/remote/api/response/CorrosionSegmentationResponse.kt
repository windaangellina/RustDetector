package com.capstone.rustdetector.source.remote.api.response

data class CorrosionSegmentationResponse(
    var url: String
)